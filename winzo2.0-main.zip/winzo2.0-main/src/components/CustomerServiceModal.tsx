import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowLeft,
  Headphones,
  Send,
  Sparkles,
  ExternalLink,
  X,
  MessageSquare,
  Mail,
  Phone,
  Radio,
  Copy,
  Check,
  ShieldCheck
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const CustomerServiceModal: React.FC = () => {
  const { isSupportOpen, setIsSupportOpen, chatMessages, sendSupportMessage, config } = useApp();
  const [inputText, setInputText] = useState('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeSupportTab, setActiveSupportTab] = useState<'CHAT' | 'CHANNELS'>('CHAT');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isSupportOpen, activeSupportTab]);

  if (!isSupportOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    sendSupportMessage(inputText);
    setInputText('');
  };

  const handleQuickPrompt = (prompt: string) => {
    sendSupportMessage(prompt);
  };

  const formatTelegramUrl = (val?: string) => {
    if (!val) return 'https://t.me';
    if (val.startsWith('http://') || val.startsWith('https://')) return val;
    const clean = val.replace('@', '').trim();
    return `https://t.me/${clean}`;
  };

  const formatWhatsappUrl = (val?: string) => {
    if (!val) return '#';
    if (val.startsWith('http://') || val.startsWith('https://')) return val;
    const clean = val.replace(/[^0-9]/g, '');
    return `https://wa.me/${clean}`;
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn text-slate-900 font-['Plus_Jakarta_Sans',sans-serif]">
      <div className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-xl h-[92vh] sm:h-auto sm:max-h-[88vh] overflow-hidden flex flex-col shadow-2xl border border-slate-200">
        
        {/* Top Header */}
        <div className="bg-white px-4 sm:px-5 py-3.5 flex items-center justify-between border-b border-slate-200 sticky top-0 z-20 shadow-2xs">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsSupportOpen(false)}
              className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-900 flex items-center justify-center font-bold">
                  <Headphones className="w-5 h-5" />
                </div>
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-white animate-pulse"></span>
              </div>
              <div>
                <h1 className="text-xs sm:text-sm font-extrabold text-slate-900 leading-tight flex items-center gap-1.5">
                  <span>WinzoPay Support Desk</span>
                  <span className="px-1.5 py-0.2 rounded-md bg-blue-100 border border-blue-200 text-blue-900 text-[10px] font-extrabold">
                    24x7
                  </span>
                </h1>
                <span className="text-[10px] text-emerald-700 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  Official Customer Service
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {config.supportTelegram && (
              <a
                href={formatTelegramUrl(config.supportTelegram)}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200 text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                title="Direct Telegram Chat"
              >
                <Send className="w-3.5 h-3.5 text-blue-600" />
                <span className="hidden sm:inline">Telegram</span>
              </a>
            )}
            <button
              onClick={() => setIsSupportOpen(false)}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 hover:text-slate-900 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Notice Banner */}
        {config.supportNotice && (
          <div className="px-4 py-2 bg-blue-50 border-b border-blue-100 flex items-center justify-between text-[11px] text-blue-950 font-semibold">
            <div className="flex items-center gap-1.5 truncate">
              <Sparkles className="w-3.5 h-3.5 text-blue-700 shrink-0" />
              <span className="truncate">{config.supportNotice}</span>
            </div>
            <span className="text-[10px] text-blue-900 font-extrabold px-1.5 py-0.5 bg-blue-200/60 border border-blue-300 rounded-md shrink-0 ml-2">
              Verified
            </span>
          </div>
        )}

        {/* Support Mode Tabs */}
        <div className="px-4 pt-2.5 pb-2 bg-white border-b border-slate-200 flex items-center gap-2">
          <button
            onClick={() => setActiveSupportTab('CHAT')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeSupportTab === 'CHAT'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Instant AI Chat</span>
          </button>
          <button
            onClick={() => setActiveSupportTab('CHANNELS')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeSupportTab === 'CHANNELS'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Headphones className="w-3.5 h-3.5" />
            <span>Official Channels & Telegram</span>
          </button>
        </div>

        {/* VIEW 1: Direct Support Channels & Telegram Accounts */}
        {activeSupportTab === 'CHANNELS' ? (
          <div className="flex-1 p-4 sm:p-5 overflow-y-auto bg-slate-50 flex flex-col gap-3">
            
            {/* Telegram Support Card */}
            {config.supportTelegram && (
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 border border-sky-200 flex items-center justify-center shadow-xs">
                      <Send className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-xs sm:text-sm font-extrabold text-slate-900">Official Telegram Support</h3>
                      <p className="text-[11px] text-slate-500">Direct 1-on-1 human agent for instant help</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-extrabold text-sky-800 bg-sky-100 px-2 py-0.5 rounded-md border border-sky-200">
                    Fastest
                  </span>
                </div>

                <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
                  <a
                    href={formatTelegramUrl(config.supportTelegram)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-extrabold flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                  >
                    <span>Open Telegram Support</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <button
                    onClick={() => handleCopy(config.supportTelegram, 'tg_support')}
                    className="p-2.5 rounded-xl border border-slate-200 bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                    title="Copy Handle"
                  >
                    {copiedKey === 'tg_support' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* Telegram Community Channel */}
            {config.officialChannel && (
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-900 border border-blue-200 flex items-center justify-center shadow-xs">
                      <Radio className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-xs sm:text-sm font-extrabold text-slate-900">Official Community Channel</h3>
                      <p className="text-[11px] text-slate-500">Daily trade signals, payment proofs & news</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-extrabold text-blue-900 bg-blue-100 px-2 py-0.5 rounded-md">
                    Community
                  </span>
                </div>

                <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
                  <a
                    href={formatTelegramUrl(config.officialChannel)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-extrabold flex items-center justify-center gap-1.5 transition-colors border border-slate-200"
                  >
                    <span>Join Official Channel</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <button
                    onClick={() => handleCopy(config.officialChannel, 'tg_channel')}
                    className="p-2.5 rounded-xl border border-slate-200 bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                    title="Copy Link"
                  >
                    {copiedKey === 'tg_channel' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* WhatsApp Support Desk */}
            {config.supportWhatsapp && (
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center shadow-xs">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-xs sm:text-sm font-extrabold text-slate-900">WhatsApp Customer Service</h3>
                      <p className="text-[11px] text-slate-500">{config.supportWhatsapp} • 24x7 Helpdesk</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-extrabold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-md border border-emerald-200">
                    24/7
                  </span>
                </div>

                <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
                  <a
                    href={formatWhatsappUrl(config.supportWhatsapp)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-extrabold flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                  >
                    <span>Chat on WhatsApp</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <button
                    onClick={() => handleCopy(config.supportWhatsapp || '', 'wa_support')}
                    className="p-2.5 rounded-xl border border-slate-200 bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                    title="Copy Number"
                  >
                    {copiedKey === 'wa_support' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* Helpline & Email Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {config.supportPhone && (
                <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 block uppercase">Phone Helpline</span>
                      <span className="text-xs font-extrabold text-slate-900">{config.supportPhone}</span>
                    </div>
                  </div>
                  <a
                    href={`tel:${config.supportPhone}`}
                    className="px-2.5 py-1.5 rounded-xl bg-blue-50 text-blue-900 hover:bg-blue-100 text-xs font-bold transition-colors"
                  >
                    Call
                  </a>
                </div>
              )}

              {config.supportEmail && (
                <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
                      <Mail className="w-4 h-4" />
                    </div>
                    <div className="truncate max-w-[140px]">
                      <span className="text-[10px] font-bold text-slate-500 block uppercase">Email Desk</span>
                      <span className="text-xs font-extrabold text-slate-900 truncate block">{config.supportEmail}</span>
                    </div>
                  </div>
                  <a
                    href={`mailto:${config.supportEmail}`}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 text-xs font-bold transition-colors"
                  >
                    Email
                  </a>
                </div>
              )}
            </div>

            <div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center gap-2 text-xs text-slate-500 font-medium">
              <ShieldCheck className="w-4 h-4 text-blue-900 shrink-0" />
              <span>All official customer service links are managed directly by WinzoPay security administrators.</span>
            </div>

          </div>
        ) : (
          /* VIEW 2: In-App Interactive Chat */
          <>
            {/* Chat Messages */}
            <div className="flex-1 p-4 sm:p-5 overflow-y-auto bg-slate-50 flex flex-col gap-3">
              {chatMessages.map(msg => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-3.5 text-xs font-medium shadow-xs ${
                      msg.sender === 'user'
                        ? 'bg-slate-900 text-white rounded-br-none'
                        : 'bg-white text-slate-800 rounded-bl-none border border-slate-200'
                    }`}
                  >
                    {msg.text}
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 px-1">{msg.time}</span>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick FAQ Prompts */}
            <div className="px-4 sm:px-5 py-2.5 bg-white border-t border-slate-200 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
              {['UTR approval status?', 'Why is sell RP pending?', 'Telegram admin contact?'].map(prompt => (
                <button
                  key={prompt}
                  onClick={() => handleQuickPrompt(prompt)}
                  className="px-3 py-1 rounded-full bg-slate-100 hover:bg-slate-200 border border-slate-200 text-[11px] font-bold text-slate-700 whitespace-nowrap transition-colors cursor-pointer"
                >
                  {prompt}
                </button>
              ))}
            </div>

            {/* Chat Input Bar */}
            <form onSubmit={handleSend} className="p-4 bg-white border-t border-slate-200 flex items-center gap-2">
              <input
                type="text"
                placeholder="Type your question or query..."
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                className="flex-1 px-4 py-3 rounded-2xl bg-slate-50 border border-slate-300 text-xs font-semibold text-slate-900 focus:outline-none focus:border-blue-900 focus:ring-1 focus:ring-blue-900 transition-all placeholder:text-slate-400"
              />
              <button
                type="submit"
                disabled={!inputText.trim()}
                className="w-11 h-11 rounded-2xl bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white flex items-center justify-center transition-all cursor-pointer shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </>
        )}

      </div>
    </div>
  );
};
