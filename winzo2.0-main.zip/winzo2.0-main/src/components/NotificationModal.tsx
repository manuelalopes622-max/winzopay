import React from 'react';
import { ArrowLeft, Bell, CheckCheck, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const NotificationModal: React.FC = () => {
  const {
    isNotificationOpen,
    setIsNotificationOpen,
    notifications,
    markAllNotificationsAsRead,
    markNotificationAsRead,
  } = useApp();

  if (!isNotificationOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn text-slate-900">
      <div className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-lg h-[92vh] sm:h-auto sm:max-h-[88vh] overflow-y-auto flex flex-col shadow-2xl border border-slate-200">
        
        {/* Top Header */}
        <div className="bg-white px-5 py-4 flex items-center justify-between border-b border-slate-200 sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsNotificationOpen(false)}
              className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
                <Bell className="w-5 h-5 text-blue-900" />
                Notifications
              </h1>
              <span className="text-[11px] text-slate-500 font-medium">
                Real-time transaction alerts & announcements
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={markAllNotificationsAsRead}
              className="text-xs font-bold text-blue-900 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <CheckCheck className="w-3.5 h-3.5" /> Mark all read
            </button>
            <button
              onClick={() => setIsNotificationOpen(false)}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 hover:text-slate-900 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="p-5 flex-1 flex flex-col gap-3 bg-slate-50/50">
          {notifications.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center py-16 text-center gap-2">
              <div className="w-14 h-14 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center">
                <Bell className="w-7 h-7" />
              </div>
              <p className="text-sm font-extrabold text-slate-900">No Notifications</p>
              <p className="text-xs text-slate-500">You are all caught up!</p>
            </div>
          ) : (
            notifications.map(n => (
              <div
                key={n.id}
                onClick={() => markNotificationAsRead(n.id)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col gap-1 ${
                  n.read
                    ? 'bg-slate-100 border-slate-200 opacity-70'
                    : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-slate-900">{n.title}</span>
                  <span className="text-[10px] text-slate-400 font-medium">{n.timestamp}</span>
                </div>
                <p className="text-xs text-slate-600 mt-0.5">{n.message}</p>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};
