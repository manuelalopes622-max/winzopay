import React, { useState, useMemo } from 'react';
import {
  ArrowLeft,
  RotateCw,
  X,
  QrCode,
  Copy,
  CheckCircle,
  ShieldCheck,
  Zap,
  Clock,
  Sparkles,
  ArrowDownLeft,
  CheckCircle2,
  Wallet,
  AlertCircle,
  HelpCircle,
  Layers,
  History,
  Check,
  ChevronRight,
  TrendingUp
} from 'lucide-react';
import { useApp } from '../context/AppContext';

const PRESET_AMOUNTS = [
  { label: '₹ 100', value: 100 },
  { label: '₹ 500', value: 500 },
  { label: '₹ 1K', value: 1000 },
  { label: '₹ 2.5K', value: 2500 },
  { label: '₹ 5K', value: 5000 },
  { label: '₹ 10K', value: 10000 },
  { label: '₹ 20K', value: 20000 },
  { label: '₹ 50K', value: 50000 },
];

export const DepositView: React.FC = () => {
  const {
    availableBalance,
    submitDeposit,
    config,
    setActiveTab,
    setIsTxHistoryOpen,
    setTxHistoryFilter,
    refreshing,
    triggerRefresh,
    depositRequests,
    transactions,
    userId,
    userPhone,
    checkBelongsToUser,
  } = useApp();

  const [selectedAmount, setSelectedAmount] = useState<number>(1000);
  const [customAmountStr, setCustomAmountStr] = useState<string>('1000');
  const [paymentMethod, setPaymentMethod] = useState<'QR' | 'UPI' | 'NET_BANKING'>('QR');
  const [utrNumber, setUtrNumber] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  const [showAllDeposits, setShowAllDeposits] = useState(false);
  const [depositFilter, setDepositFilter] = useState<'ALL' | 'SUCCESS' | 'PENDING' | 'REJECTED'>('ALL');
  const [depositSearch, setDepositSearch] = useState('');
  const [selectedDepositReceipt, setSelectedDepositReceipt] = useState<{
    id: string;
    amount: number;
    status: 'SUCCESS' | 'PENDING' | 'PROCESSING' | 'REJECTED';
    utr?: string;
    method?: string;
    createdAt: string;
  } | null>(null);

  // Compute user deposits and amounts for Approved, Pending, and Rejected
  const userDeposits = useMemo(() => {
    const reqMap = new Map<
      string,
      {
        id: string;
        amount: number;
        status: 'SUCCESS' | 'PENDING' | 'PROCESSING' | 'REJECTED';
        utr?: string;
        method?: string;
        createdAt: string;
      }
    >();

    const cleanPhone = (userPhone || '').replace(/\D/g, '');

    // 1. Ingest from depositRequests (real-time Firestore synced, strictly for authenticated user)
    depositRequests.forEach((req) => {
      if (checkBelongsToUser(req, userId, cleanPhone)) {
        const key = req.utr && req.utr.trim().length >= 4 
          ? `utr_${req.utr.trim().toLowerCase()}` 
          : `id_${req.id}`;
        reqMap.set(key, {
          id: req.id,
          amount: req.amount,
          status: req.status === 'PROCESSING' ? 'PENDING' : req.status,
          utr: req.utr,
          method: req.method || 'QR',
          createdAt: req.createdAt,
        });
      }
    });

    // 2. Ingest from ledger transactions of type BUY_RP or DEPOSIT (strictly for authenticated user)
    transactions
      .filter((t) => (t.type === 'DEPOSIT' || t.type === 'BUY_RP') && checkBelongsToUser(t, userId, cleanPhone))
      .forEach((tx) => {
        const key = tx.utr && tx.utr.trim().length >= 4 
          ? `utr_${tx.utr.trim().toLowerCase()}` 
          : `id_${tx.id}`;
        const existing = reqMap.get(key);
        if (existing) {
          // Merge statuses: if either is SUCCESS, mark SUCCESS!
          if (tx.status === 'SUCCESS' || existing.status === 'SUCCESS') {
            existing.status = 'SUCCESS';
          } else if (tx.status === 'REJECTED' || existing.status === 'REJECTED') {
            existing.status = 'REJECTED';
          }
        } else {
          // Check if notes reference an existing order ID or matching UTR
          let matched = false;
          for (const [, val] of reqMap.entries()) {
            const matchesOrderId = tx.notes && tx.notes.includes(val.id);
            const matchesUtr = val.utr && tx.utr && val.utr.trim().toLowerCase() === tx.utr.trim().toLowerCase();
            if (matchesOrderId || matchesUtr) {
              if (tx.status === 'SUCCESS' || val.status === 'SUCCESS') {
                val.status = 'SUCCESS';
              } else if (tx.status === 'REJECTED' || val.status === 'REJECTED') {
                val.status = 'REJECTED';
              }
              matched = true;
              break;
            }
          }
          if (!matched) {
            reqMap.set(key, {
              id: tx.id,
              amount: tx.amount,
              status: tx.status === 'PROCESSING' ? 'PENDING' : tx.status,
              utr: tx.utr,
              method: 'UPI',
              createdAt: tx.createdAt || tx.timestamp,
            });
          }
        }
      });

    return Array.from(reqMap.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [depositRequests, transactions, userId, userPhone]);

  const filteredUserDeposits = useMemo(() => {
    return userDeposits.filter((dep) => {
      if (depositFilter === 'SUCCESS' && dep.status !== 'SUCCESS') return false;
      if (depositFilter === 'PENDING' && dep.status !== 'PENDING' && dep.status !== 'PROCESSING') return false;
      if (depositFilter === 'REJECTED' && dep.status !== 'REJECTED') return false;

      if (depositSearch.trim()) {
        const q = depositSearch.toLowerCase().trim();
        const matchId = dep.id.toLowerCase().includes(q);
        const matchUtr = dep.utr?.toLowerCase().includes(q);
        const matchMethod = dep.method?.toLowerCase().includes(q);
        const matchAmt = dep.amount.toString().includes(q);
        return matchId || matchUtr || matchMethod || matchAmt;
      }
      return true;
    });
  }, [userDeposits, depositFilter, depositSearch]);

  const totalApprovedDeposits = useMemo(() => {
    return userDeposits
      .filter((d) => d.status === 'SUCCESS')
      .reduce((sum, d) => sum + (d.amount || 0), 0);
  }, [userDeposits]);

  const totalPendingDeposits = useMemo(() => {
    return userDeposits
      .filter((d) => d.status === 'PENDING' || d.status === 'PROCESSING')
      .reduce((sum, d) => sum + (d.amount || 0), 0);
  }, [userDeposits]);

  const approvedCount = userDeposits.filter((d) => d.status === 'SUCCESS').length;
  const pendingCount = userDeposits.filter((d) => d.status === 'PENDING' || d.status === 'PROCESSING').length;
  const rejectedCount = userDeposits.filter((d) => d.status === 'REJECTED').length;

  const handleAmountChipClick = (amount: number) => {
    setSelectedAmount(amount);
    setCustomAmountStr(amount.toString());
    setErrorMessage('');
  };

  const handleInputChange = (val: string) => {
    const numeric = val.replace(/\D/g, '');
    setCustomAmountStr(numeric);
    const num = parseInt(numeric, 10);
    if (!isNaN(num)) {
      setSelectedAmount(num);
    } else {
      setSelectedAmount(0);
    }
    setErrorMessage('');
  };

  const handleClear = () => {
    setCustomAmountStr('');
    setSelectedAmount(0);
  };

  const handleCopyUpi = () => {
    navigator.clipboard?.writeText(config.upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2500);
  };

  const handleInitiatePayment = () => {
    const amt = parseInt(customAmountStr, 10);
    if (!amt || amt < config.minDeposit) {
      setErrorMessage(`Minimum deposit amount is ₹${config.minDeposit}`);
      return;
    }
    if (amt > config.maxDeposit) {
      setErrorMessage(`Maximum deposit amount is ₹${config.maxDeposit.toLocaleString('en-IN')}`);
      return;
    }
    setErrorMessage('');
    setShowPaymentModal(true);
  };

  const handleFinalSubmitDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!utrNumber || utrNumber.trim().length < 8) {
      setErrorMessage('Please enter a valid 12-digit UTR/Ref number.');
      return;
    }

    const amt = parseInt(customAmountStr, 10);
    const success = submitDeposit(amt, utrNumber.trim(), paymentMethod === 'QR' ? 'QR' : 'UPI');

    if (success) {
      setSubmittedSuccess(true);
      setShowPaymentModal(false);
      setUtrNumber('');
    } else {
      setErrorMessage('Failed to queue deposit request. Please check amount.');
    }
  };

  const currentAmt = parseInt(customAmountStr, 10) || 0;

  return (
    <div className="min-h-screen bg-slate-50 pb-28 text-slate-900" id="deposit-view-container">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 py-3.5 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('home')}
            id="deposit-back-btn"
            className="p-1.5 -ml-1 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <ArrowDownLeft className="w-4 h-4 text-blue-900" />
              Top-Up Balance (Deposit)
            </h1>
            <p className="text-[11px] text-slate-500">Step 1: Deposit funds to purchase RP Plans</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={triggerRefresh}
            id="deposit-refresh-btn"
            className={`p-2 text-slate-600 hover:text-slate-900 rounded-full hover:bg-slate-100 transition-colors cursor-pointer ${
              refreshing ? 'animate-spin text-blue-900' : ''
            }`}
            title="Refresh balance"
          >
            <RotateCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="max-w-xl mx-auto px-4 pt-4 space-y-4">
        {/* Step Indicator Banner */}
        <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-3.5 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-blue-900 text-white font-bold flex items-center justify-center text-sm shadow-xs">
                1
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  Deposit to Top-Up Balance
                  <span className="bg-blue-100 text-blue-900 text-[10px] px-2 py-0.5 rounded-full font-bold">Active Step</span>
                </p>
                <p className="text-[11px] text-slate-600">Funds go to your Top-Up balance for purchasing RP Mining Plans</p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('buy_rp')}
              className="text-xs font-bold text-blue-900 hover:underline flex items-center gap-1 bg-white px-2.5 py-1.5 rounded-lg border border-blue-200 cursor-pointer shadow-xs"
            >
              Step 2: Buy RP →
            </button>
          </div>
        </div>

        {/* Current Top-Up Balance Card */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-500 flex items-center gap-1.5 font-medium">
                <Wallet className="w-3.5 h-3.5 text-blue-900" />
                Current Top-Up Balance
              </span>
              <div className="text-2xl font-black text-slate-900 mt-1">
                ₹{availableBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div className="flex flex-col items-end gap-1">
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-950 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-900" />
                Verified Wallet
              </span>
              <span className="text-[11px] text-slate-500">100% Secure Gateway</span>
            </div>
          </div>
        </div>

        {/* User's Approved & Pending Deposit Money Summary */}
        <div className="grid grid-cols-2 gap-3" id="deposit-approved-pending-summary">
          {/* Approved Money Card */}
          <div className="bg-white border border-emerald-200/80 rounded-2xl p-3.5 shadow-xs relative overflow-hidden bg-gradient-to-br from-emerald-50/40 via-white to-white">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-bold text-emerald-800 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                Approved Money
              </span>
              <span className="text-[10px] font-bold bg-emerald-100/80 text-emerald-800 px-1.5 py-0.5 rounded-md border border-emerald-200">
                {approvedCount} Done
              </span>
            </div>
            <div className="text-lg font-black text-slate-900 tracking-tight">
              ₹{totalApprovedDeposits.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">Credited to wallet</p>
          </div>

          {/* Pending Money Card */}
          <div className="bg-white border border-amber-200/80 rounded-2xl p-3.5 shadow-xs relative overflow-hidden bg-gradient-to-br from-amber-50/40 via-white to-white">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-bold text-amber-800 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                Pending Money
              </span>
              <span className="text-[10px] font-bold bg-amber-100/80 text-amber-800 px-1.5 py-0.5 rounded-md border border-amber-200">
                {pendingCount} In Review
              </span>
            </div>
            <div className="text-lg font-black text-slate-900 tracking-tight">
              ₹{totalPendingDeposits.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">Awaiting verification</p>
          </div>
        </div>

        {/* Success Feedback Alert */}
        {submittedSuccess && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 space-y-3 animate-in fade-in duration-300">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-slate-900">Deposit Request Logged Successfully!</h4>
                <p className="text-xs text-slate-600 mt-1">
                  Your deposit has been saved to the database. Once verified by Admin, your Top-Up balance will update automatically and you can purchase your RP Plan.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => {
                  setSubmittedSuccess(false);
                  setActiveTab('buy_rp');
                }}
                className="flex-1 py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition shadow-sm text-center cursor-pointer"
              >
                Go to Buy RP Plans →
              </button>
              <button
                onClick={() => {
                  setSubmittedSuccess(false);
                  setTxHistoryFilter('DEPOSIT');
                  setIsTxHistoryOpen(true);
                }}
                className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition text-center cursor-pointer border border-slate-200"
              >
                View History
              </button>
            </div>
          </div>
        )}

        {/* Error Alert */}
        {errorMessage && (
          <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 flex items-center gap-2 text-rose-700 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Amount Selection Section */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-900"></span>
              Enter Top-Up Amount
            </h2>
            <span className="text-xs text-slate-500">
              Min: ₹{config.minDeposit} | Max: ₹{config.maxDeposit.toLocaleString('en-IN')}
            </span>
          </div>

          {/* Amount Input Box */}
          <div className="relative">
            <div className="flex items-center bg-slate-50 rounded-xl border border-slate-200 px-4 py-3 focus-within:border-slate-900 focus-within:bg-white transition-all">
              <span className="text-xl font-bold text-slate-900 mr-2">₹</span>
              <input
                type="text"
                inputMode="numeric"
                value={customAmountStr}
                onChange={(e) => handleInputChange(e.target.value)}
                placeholder="0"
                id="deposit-amount-input"
                className="w-full bg-transparent text-xl font-bold text-slate-900 placeholder-slate-400 focus:outline-none"
              />
              {customAmountStr && (
                <button
                  type="button"
                  onClick={handleClear}
                  className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Quick Preset Buttons */}
          <div className="grid grid-cols-4 gap-2">
            {PRESET_AMOUNTS.map((preset) => (
              <button
                key={preset.value}
                type="button"
                onClick={() => handleAmountChipClick(preset.value)}
                id={`deposit-preset-${preset.value}`}
                className={`py-2 px-1 text-center rounded-xl font-bold text-xs transition-all border cursor-pointer ${
                  selectedAmount === preset.value
                    ? 'bg-blue-900 text-white border-blue-900 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300 hover:bg-slate-100'
                }`}
              >
                {preset.label}
              </button>
            ))}
          </div>

          {/* Deposit Summary Preview */}
          <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">Deposit Amount:</span>
              <span className="font-bold text-slate-900">₹{currentAmt.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">Gateway Handling Fee:</span>
              <span className="font-bold text-emerald-700">₹0 (FREE 0%)</span>
            </div>
            <div className="flex justify-between text-xs pt-1 border-t border-slate-200">
              <span className="text-slate-700 font-semibold">Credited to Top-Up Balance:</span>
              <span className="font-black text-slate-900">₹{currentAmt.toLocaleString('en-IN')}</span>
            </div>
          </div>

          {/* Proceed Button */}
          <button
            type="button"
            onClick={handleInitiatePayment}
            id="deposit-proceed-btn"
            disabled={!currentAmt || currentAmt < config.minDeposit}
            className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold rounded-xl transition shadow-sm flex items-center justify-center gap-2 text-sm cursor-pointer"
          >
            <ArrowDownLeft className="w-4 h-4" />
            Proceed to Payment (₹{currentAmt.toLocaleString('en-IN')})
          </button>
        </div>

        {/* User's All Deposit Activity & Status Log */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3" id="deposit-recent-status-list">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <History className="w-3.5 h-3.5 text-blue-900" />
                Your Deposit Activity & History
              </h3>
              <p className="text-[10px] text-slate-500 font-medium">
                {userDeposits.length} Total Top-Up Deposit{userDeposits.length !== 1 ? 's' : ''} on record
              </p>
            </div>
            <button
              type="button"
              id="deposit-view-full-ledger-btn"
              onClick={() => {
                setTxHistoryFilter('DEPOSIT');
                setIsTxHistoryOpen(true);
              }}
              className="text-[11px] font-bold text-blue-900 hover:underline flex items-center gap-0.5 cursor-pointer bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200"
            >
              Full Ledger <ChevronRight className="w-3 h-3" />
            </button>
          </div>

          {userDeposits.length === 0 ? (
            <div className="py-6 text-center text-xs text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
              No deposit history yet. Submit your first top-up above!
            </div>
          ) : (
            <div className="space-y-3">
              {/* Deposit Filter Tabs */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
                {[
                  { id: 'ALL', label: 'All Deposits', count: userDeposits.length },
                  { id: 'SUCCESS', label: 'Approved', count: approvedCount },
                  { id: 'PENDING', label: 'In Review', count: pendingCount },
                  { id: 'REJECTED', label: 'Rejected', count: rejectedCount },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setDepositFilter(tab.id as any)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                      depositFilter === tab.id
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    <span>{tab.label}</span>
                    <span
                      className={`px-1.5 py-0.2 rounded-full text-[9px] ${
                        depositFilter === tab.id
                          ? 'bg-slate-700 text-slate-200'
                          : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {tab.count}
                    </span>
                  </button>
                ))}
              </div>

              {/* Deposit Quick Search Bar if there are multiple items */}
              {userDeposits.length > 3 && (
                <input
                  type="text"
                  placeholder="Search deposits by UTR, Order ID, Method..."
                  value={depositSearch}
                  onChange={(e) => setDepositSearch(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-900"
                />
              )}

              {/* Deposit List */}
              <div className="space-y-2">
                {filteredUserDeposits.length === 0 ? (
                  <p className="text-center py-4 text-xs text-slate-400">
                    No deposits found matching selected filter.
                  </p>
                ) : (
                  (showAllDeposits ? filteredUserDeposits : filteredUserDeposits.slice(0, 4)).map((dep) => {
                    const isApproved = dep.status === 'SUCCESS';
                    const isPending = dep.status === 'PENDING' || dep.status === 'PROCESSING';
                    return (
                      <div
                        key={dep.id}
                        id={`deposit-item-${dep.id}`}
                        onClick={() => setSelectedDepositReceipt(dep)}
                        className="p-3 rounded-xl bg-slate-50 hover:bg-slate-100/80 border border-slate-200/90 flex items-center justify-between text-xs cursor-pointer transition shadow-2xs"
                      >
                        <div className="flex items-start gap-2.5">
                          <div
                            className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                              isApproved
                                ? 'bg-emerald-100 text-emerald-800'
                                : isPending
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {isApproved ? (
                              <Check className="w-4 h-4" />
                            ) : isPending ? (
                              <Clock className="w-3.5 h-3.5 animate-pulse" />
                            ) : (
                              <X className="w-4 h-4" />
                            )}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 flex items-center gap-1.5">
                              <span className="text-sm">+₹{dep.amount.toLocaleString('en-IN')}</span>
                              <span className="text-[10px] text-slate-500 font-normal">
                                ({dep.method || 'QR'})
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                              {dep.utr ? `UTR: ${dep.utr}` : `Ref: ${dep.id}`}
                            </div>
                          </div>
                        </div>

                        <div className="text-right flex flex-col items-end">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              isApproved
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                : isPending
                                ? 'bg-amber-100 text-amber-800 border border-amber-200'
                                : 'bg-rose-100 text-rose-800 border border-rose-200'
                            }`}
                          >
                            {isApproved ? 'Approved' : isPending ? 'In Review' : 'Rejected'}
                          </span>
                          <p className="text-[9px] text-slate-400 mt-1">
                            {new Date(dep.createdAt).toLocaleDateString('en-IN', {
                              day: 'numeric',
                              month: 'short',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </p>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Toggle Show All vs Recent */}
              {filteredUserDeposits.length > 4 && (
                <button
                  type="button"
                  onClick={() => setShowAllDeposits(!showAllDeposits)}
                  className="w-full py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer text-center"
                >
                  {showAllDeposits
                    ? `Show Less (Top 4)`
                    : `View All ${filteredUserDeposits.length} Deposit Records ↓`}
                </button>
              )}
            </div>
          )}
        </div>

        {/* Deposit Guidelines */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200 space-y-2.5 text-xs text-slate-600 shadow-xs">
          <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
            <HelpCircle className="w-4 h-4 text-blue-900" />
            Top-Up Instructions
          </div>
          <ul className="space-y-1.5 list-disc list-inside text-[11px] leading-relaxed text-slate-600">
            <li>Scan the official QR code or copy the UPI ID to pay via PhonePe, GPay, Paytm, or BHIM.</li>
            <li>After successful transfer, enter the <strong>12-digit UTR/Ref Number</strong>.</li>
            <li>Your Top-Up balance will be credited upon database verification.</li>
            <li>Once credited, proceed to <strong>Step 2: Buy RP</strong> to purchase and activate your mining plan.</li>
          </ul>
        </div>
      </div>

      {/* Payment Drawer / Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl space-y-4 p-5 max-h-[90vh] overflow-y-auto text-slate-900">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-900">Complete Top-Up Deposit</h3>
                <p className="text-xs text-slate-500">Amount: ₹{currentAmt.toLocaleString('en-IN')}</p>
              </div>
              <button
                onClick={() => setShowPaymentModal(false)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Official QR Code Box */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-center space-y-3">
              <p className="text-xs text-slate-600 font-medium">Scan QR code using any UPI App</p>
              <div className="inline-block p-3 bg-white rounded-2xl border border-slate-200 shadow-sm">
                <img
                  src={config.qrCodeUrl}
                  alt="WinzoPay Deposit UPI QR"
                  className="w-44 h-44 object-contain mx-auto"
                />
              </div>
              <div className="flex items-center justify-center gap-1.5 text-xs text-blue-900 font-bold">
                <Zap className="w-3.5 h-3.5" />
                Instant 24x7 UPI Gateway
              </div>
            </div>

            {/* Official UPI ID Box */}
            <div className="bg-slate-50 rounded-2xl p-3 border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">Official UPI ID</span>
                <span className="text-xs font-mono font-bold text-slate-900">{config.upiId}</span>
              </div>
              <button
                type="button"
                onClick={handleCopyUpi}
                id="deposit-copy-upi-btn"
                className="py-1.5 px-3 bg-white hover:bg-slate-100 text-slate-800 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition border border-slate-200 cursor-pointer shadow-xs"
              >
                {copiedUpi ? (
                  <>
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    Copy UPI
                  </>
                )}
              </button>
            </div>

            {/* UTR Input Form */}
            <form onSubmit={handleFinalSubmitDeposit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5">
                  Enter 12-Digit UTR / Transaction Reference ID <span className="text-rose-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  maxLength={24}
                  placeholder="e.g. 423589124012"
                  value={utrNumber}
                  onChange={(e) => {
                    setUtrNumber(e.target.value.replace(/[^a-zA-Z0-9]/g, ''));
                    setErrorMessage('');
                  }}
                  id="deposit-utr-input"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-mono font-semibold text-slate-900 placeholder-slate-400 focus:outline-none focus:border-slate-900 focus:bg-white"
                />
                <p className="text-[10px] text-slate-500 mt-1">Found in your payment receipt from PhonePe / GPay / Paytm</p>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="w-1/3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="deposit-submit-utr-btn"
                  className="w-2/3 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle className="w-4 h-4" />
                  Submit Deposit Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Deposit Receipt Modal */}
      {selectedDepositReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl p-5 space-y-4 text-slate-900">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="text-sm font-extrabold text-slate-900">Deposit Order Receipt</h3>
              <button
                onClick={() => setSelectedDepositReceipt(null)}
                className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-center py-2">
              <div
                className={`w-12 h-12 rounded-2xl mx-auto flex items-center justify-center mb-2 ${
                  selectedDepositReceipt.status === 'SUCCESS'
                    ? 'bg-emerald-100 text-emerald-800'
                    : selectedDepositReceipt.status === 'REJECTED'
                    ? 'bg-rose-100 text-rose-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {selectedDepositReceipt.status === 'SUCCESS' ? (
                  <Check className="w-6 h-6" />
                ) : selectedDepositReceipt.status === 'REJECTED' ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Clock className="w-6 h-6 animate-pulse" />
                )}
              </div>
              <div className="text-2xl font-black text-slate-900">
                ₹{selectedDepositReceipt.amount.toLocaleString('en-IN')}
              </div>
              <span
                className={`inline-block mt-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
                  selectedDepositReceipt.status === 'SUCCESS'
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                    : selectedDepositReceipt.status === 'REJECTED'
                    ? 'bg-rose-100 text-rose-800 border border-rose-200'
                    : 'bg-amber-100 text-amber-800 border border-amber-200'
                }`}
              >
                {selectedDepositReceipt.status === 'SUCCESS'
                  ? 'Deposit Approved & Credited'
                  : selectedDepositReceipt.status === 'REJECTED'
                  ? 'Deposit Rejected'
                  : 'Pending Admin Verification'}
              </span>
            </div>

            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-2.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Order ID:</span>
                <span className="font-mono font-bold text-slate-900">{selectedDepositReceipt.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Method:</span>
                <span className="font-bold text-slate-900 uppercase">{selectedDepositReceipt.method || 'QR Gateway'}</span>
              </div>
              {selectedDepositReceipt.utr && (
                <div className="flex justify-between">
                  <span className="text-slate-500">UTR / Ref:</span>
                  <span className="font-mono font-bold text-slate-900">{selectedDepositReceipt.utr}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-slate-500">Created At:</span>
                <span className="font-semibold text-slate-700">
                  {new Date(selectedDepositReceipt.createdAt).toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-200">
                <span className="text-slate-700 font-semibold">Credited Wallet:</span>
                <span className="font-bold text-blue-900">Top-Up Balance</span>
              </div>
            </div>

            <button
              onClick={() => setSelectedDepositReceipt(null)}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition cursor-pointer"
            >
              Close Receipt
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
