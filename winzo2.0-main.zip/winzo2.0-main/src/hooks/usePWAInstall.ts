import { useEffect, useState, useCallback } from 'react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

const STORAGE_KEY_DOWNLOADED = 'winzopay_apk_downloaded';
const STORAGE_KEY_INSTALLED = 'winzopay_app_installed';

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);

  // Check if currently running inside the installed standalone PWA application
  const [isStandaloneApp, setIsStandaloneApp] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return (
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true ||
      document.referrer.includes('android-app://')
    );
  });

  const [isInstalled, setIsInstalled] = useState<boolean>(isStandaloneApp);
  const [isDownloaded, setIsDownloaded] = useState<boolean>(false);

  const [isIOS, setIsIOS] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);

  useEffect(() => {
    // Clear any stale download flags so buttons are never hidden from the user on the website
    try {
      localStorage.removeItem(STORAGE_KEY_DOWNLOADED);
      localStorage.removeItem(STORAGE_KEY_INSTALLED);
    } catch {}

    const checkStandalone = () => {
      const isStandalone =
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as unknown as { standalone?: boolean }).standalone === true ||
        document.referrer.includes('android-app://');

      setIsStandaloneApp(isStandalone);
      setIsInstalled(isStandalone);
    };

    checkStandalone();

    const mediaQuery = window.matchMedia('(display-mode: standalone)');
    const handleMediaChange = (e: MediaQueryListEvent) => {
      setIsStandaloneApp(e.matches);
      setIsInstalled(e.matches);
    };

    try {
      mediaQuery.addEventListener('change', handleMediaChange);
    } catch {}

    // Detect user platform
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
    const isAndroidDevice = /android/.test(userAgent);
    setIsIOS(isIOSDevice);
    setIsAndroid(isAndroidDevice);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setIsDownloaded(true);
      try {
        localStorage.setItem(STORAGE_KEY_INSTALLED, 'true');
        localStorage.setItem(STORAGE_KEY_DOWNLOADED, 'true');
      } catch {}
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      try {
        mediaQuery.removeEventListener('change', handleMediaChange);
      } catch {}
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const downloadApk = useCallback(() => {
    // If inside an iframe (such as AI Studio preview), use window.open so the browser does not block the download
    const isIframe = typeof window !== 'undefined' && window.self !== window.top;
    if (isIframe) {
      window.open('/api/download-apk', '_blank');
    } else {
      const link = document.createElement('a');
      link.href = '/api/download-apk';
      link.setAttribute('download', 'WinzoPay.apk');
      link.setAttribute('target', '_blank');
      link.setAttribute('rel', 'noopener noreferrer');
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) {
          document.body.removeChild(link);
        }
      }, 1000);
    }

    // Mark as downloaded in state and persistent storage so download/install buttons disappear
    setIsDownloaded(true);
    try {
      localStorage.setItem(STORAGE_KEY_DOWNLOADED, 'true');
    } catch {}
  }, []);

  const install = useCallback(async (): Promise<'installed' | 'dismissed' | 'iframe_redirect' | 'guide'> => {
    const isIframe = typeof window !== 'undefined' && window.self !== window.top;
    if (isIframe) {
      // In an iframe (such as AI Studio preview), the browser sandbox blocks PWA install prompts.
      // Open in a new top-level tab so the browser can directly prompt app installation!
      window.open(window.location.href, '_blank');
      return 'iframe_redirect';
    }

    if (!deferredPrompt) {
      return 'guide';
    }

    try {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
        setIsDownloaded(true);
        try {
          localStorage.setItem(STORAGE_KEY_INSTALLED, 'true');
          localStorage.setItem(STORAGE_KEY_DOWNLOADED, 'true');
        } catch {}
        setDeferredPrompt(null);
        return 'installed';
      }
      return 'dismissed';
    } catch (err) {
      console.warn('Install prompt error:', err);
      return 'guide';
    }
  }, [deferredPrompt]);

  // Combined smart handler: installs directly if supported; otherwise downloads APK
  const handleSmartInstallOrDownload = useCallback(async () => {
    if (deferredPrompt) {
      const outcome = await install();
      if (outcome === 'installed') {
        return 'installed';
      }
    }
    downloadApk();
    return 'downloaded';
  }, [deferredPrompt, install, downloadApk]);

  const resetInstallState = useCallback(() => {
    try {
      localStorage.removeItem(STORAGE_KEY_DOWNLOADED);
      localStorage.removeItem(STORAGE_KEY_INSTALLED);
    } catch {}
    setIsDownloaded(false);
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true ||
      document.referrer.includes('android-app://');
    setIsInstalled(isStandalone);
  }, []);

  return {
    isInstallable: !!deferredPrompt,
    isInstalled: isStandaloneApp,
    isDownloaded,
    isStandaloneApp,
    isDownloadedOrInstalled: isStandaloneApp,
    isIOS,
    isAndroid,
    install,
    downloadApk,
    handleSmartInstallOrDownload,
    resetInstallState,
  };
}

